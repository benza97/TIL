# CLI 문법

- ls : 목록 `list`

- mkdir : 디렉토리 생성 `make directory`

- cd: 디렉토리 이동 `change directory`

 - . : 현재 디렉토리 ..: 상위 디렉토리

 - touch : 새로운 파일을 생성

 - rm : 삭제 `remove` 폴더 삭제 시 `rm -r`




 
 